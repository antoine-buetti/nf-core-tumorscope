rm -rf .nextflow*  work  test_results/
